from crewai import Task
from textwrap import dedent
from tools.CodeFileInput import CodeFileInput
from tools.ProjectStructureInput import ProjectStructureInput
from tools.CodeFileManager import CodeFileManager
from tools.CodeFileWriter import CodeFileWriter

class TestTasks:

    def create_issue_analysis_task(self, agent, code_file, description, lineNumber):
        return Task(
            description=dedent(f'''
            Review the provided Code_File_Path, Issue_Description, Issue_Line_Number based on that analyze the listed security issue. 
            Identify root causes of the issues and create potential remediations plan.
            
            **Parameters**:
            - Code_File_Path: {code_file}
            - Issue_Description: {description}
            - Issue_Line_Number: {lineNumber}
            
            **Note**: The analysis must be thorough and include recommendations for remediation of the issue listed.
            '''),
            expected_output="Your Final answer must include the detail analysis and remediation plan for issue.",
            tools=[CodeFileInput.retrieve_code_file, 
                ProjectStructureInput.get_project_structure],
            agent=agent
        )


    def create_impact_review_task(self, agent, code_file, description, lineNumber, project_path):
        return Task(
            description=dedent(f'''
                Review the provided detail analysis and remediation plan of the security issues and try to
                the Determine if these changes could introduce breaking changes or if they affect existing functionality.
                You can use the below given parameters to read the code file content. Also you can use the Project_root_dir_Path to get 
                complete project structure or specific file path to review any file, use tools iffectivly to identify the imapct of changes.
            
            **Parameters**:
            - Code_File_Path: {code_file}
            - Issue_Description: {description}
            - Issue_Line_Number: {lineNumber}
            - Project_root_dir_Path: {project_path}
            '''),
            expected_output="Your Final answer must include a detailed report of impact assessment, along with analysis and remediation plan for issue, nothing else.",
            tools=[ProjectStructureInput.get_project_structure,
                   CodeFileInput.retrieve_code_file,],
            agent=agent
        )


    def create_code_remediation_task(self, agent, code_file, description, lineNumber):
        return Task(
            description=dedent(f'''
                Using the provided detailed report of impact assessment, along with analysis and remediation plan for issue, implement the necessary code changes to fix the identified security issues in the code file. Ref the below details about file.Ensure that the changes adhere to security best practices. If you thing your changes can cause the failure then no need to make any changes. 
                
            **Parameters**: 
            - Code_File_Path: {code_file}
            - Issue_Description: {description}
            - Issue_Line_Number: {lineNumber}
            '''),
            expected_output="Your Final answer must include the updated code, nothing else.",
            tools=[CodeFileInput.retrieve_code_file],
            agent=agent
        )


    def create_code_review_task(self, agent, code_file, description,lineNumber):
        return Task(
            description=dedent(f'''
                Review the provided code with below given code_file_path to ensure that provided code  
                resolve the security issues. Validate that the fixes follow best practices and do not 
                introduce new issues, check the code for syntax errors/missing brackets. 
            
            **Parameters**: 
            - Code_File_Path: {code_file}
            - Issue_Description: {description}
            - Issue_Line_Number: {lineNumber}
            '''),
            expected_output="Your Final answer must be reviewed code, nothing else.",
            tools=[CodeFileInput.retrieve_code_file],
            output_file="final.txt",
            agent=agent
        )
    
    def create_code_rewriter_task(self, agent, reviewed_code_file):
        return Task(
            description=dedent(f'''
                Take the given code and write this into the below given code file path.               
            **Parameters**: 
            - Code_File_Path: {reviewed_code_file}           
            '''),
            expected_output="Updated code in given file location, nothing else",
            tools=[CodeFileWriter.rewrite_code_file],
            agent=agent
        )


