from crewai import Agent
from textwrap import dedent
from dotenv import load_dotenv
from tools.CodeFileInput import CodeFileInput
from tools.ProjectStructureInput import ProjectStructureInput
from tools.CodeFileManager import CodeFileManager
from tools.CodeFileWriter import CodeFileWriter
load_dotenv()
from langchain_community.llms import Ollama
from langchain_google_genai import ChatGoogleGenerativeAI
import os

"""
Notes:
- Agents should be results driven and have a clear goal in mind
- Role is their job title
- Goals should actionable
- Backstory should be their resume
"""
class CodeRefactor:
    def __init__(self):
        self.model = Ollama(model="gemma2")# type: ignore
        # self.model = ChatGoogleGenerativeAI(model="gemini-1.5-flash",
        #             verbose=True,
        #             temperature=0.5,
        #             google_api_key=os.getenv("GOOGLE_API_KEY")) # type: ignore
        

    def issue_analysis_agent(self):
        return Agent(
            role='Issue Analysis Expert',
            goal='Analyze the security issues in the codebase and identify the root cause.',
            backstory=dedent("""\
                You are an Issue Analysis Expert specializing in identifying security vulnerabilities 
                within codebases. You have expertise in security analysis tools, static analysis, 
                and understanding common vulnerabilities like SQL injection, XSS, and buffer overflow. 
                Your job is to analyze each issue in detail and suggest potential fixes."""),
            allow_delegation=False,
            memory=True,
            verbose=True,
            tools=[CodeFileInput.retrieve_code_file, 
                   ProjectStructureInput.get_project_structure],
            max_iter=5,
            llm=self.model
        )

    def impact_review_agent(self):
        return Agent(
            role='Impact Review Specialist',
            goal='Review the analysis and assess the impact of the required changes on the existing codebase.',
            backstory=dedent("""\
                You are an Impact Review Specialist experienced in determining the implications of code changes 
                on software functionality. You have a strong background in reviewing analysis reports 
                and assessing the potential for breaking changes, regressions, or unintended side effects. 
                Your task is to evaluate if the proposed fixes maintain system integrity and do not 
                disrupt current operations."""),
            allow_delegation=False,
            memory=True,
            tools=[CodeFileInput.retrieve_code_file, 
                ProjectStructureInput.get_project_structure],
            verbose=True,
            max_iter=8,
            llm=self.model
        )

    def code_change_agent(self):
        return Agent(
            role='Code Remediation Specialist',
            goal='Implement necessary code changes to resolve the security issues in the codebase.',
            backstory=dedent("""\
                You are a Code Remediation Specialist with a deep understanding of secure coding practices 
                and software refactoring. You are adept at applying security fixes while preserving the 
                overall functionality and performance of the application. Your primary responsibility is 
                to modify the code as per the analysis and recommendations provided."""),
            allow_delegation=False,
            tools=[CodeFileInput.retrieve_code_file, 
                ProjectStructureInput.get_project_structure],
            memory=True,
            max_iter=5,
            verbose=True,
            llm=self.model
        )

    def code_review_agent(self):
        return Agent(
            role='Code Review Specialist',
            goal='Review the changes and ensure they meet security standards without breaking functionality.',
            backstory=dedent("""\
                You are a Code Review Specialist with a focus on verifying that security fixes 
                are correctly applied. You ensure that the changes do not introduce new issues, 
                maintain code quality, and adhere to security best practices. Your task is to 
                pass the changes for final review if all checks pass."""),
            allow_delegation=False,
            memory=True,
            tools=[CodeFileInput.retrieve_code_file],
            verbose=True,
            max_iter=5,
            llm=self.model
        )

    def code_rewriter_agent(self):
        return Agent(
            role='Code Rewriter',
            goal='Rewrite the file with new changes ensuring all improvements are properly integrated.',
            backstory=dedent("""\
                You are a Code Rewriter specializing in integrating security improvements into the codebase. 
                You ensure that the rewritten code adheres to standards, integrates smoothly, and functions 
                as intended. Your responsibility is to finalize the changes and prepare the code for deployment."""),
            allow_delegation=False,
            memory=True,
            verbose=True,
            tools=[CodeFileWriter.rewrite_code_file],
            max_iter=4,
            llm=self.model
        )

