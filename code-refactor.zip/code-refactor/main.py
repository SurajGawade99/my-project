from crewai import Crew
from textwrap import dedent
from agents import CodeRefactor
from tasks import TestTasks

from dotenv import load_dotenv
load_dotenv()


class TripCrew:
    def __init__(self, code_file, description, line_number, project_root_dir):
        self.code_file = code_file
        self.description = description
        self.line_number = line_number
        self.project_root_dir = project_root_dir
        
    def run(self):
        agents = CodeRefactor()
        tasks = TestTasks()

        # Define your custom agents and tasks here
        issue_analysis_agent=agents.issue_analysis_agent()
        impact_review_agent=agents.impact_review_agent()
        code_change_agent=agents.code_change_agent()
        code_review_agent=agents.code_review_agent()
        code_rewriter_agent=agents.code_rewriter_agent()
        
        
        create_issue_analysis_task= tasks.create_issue_analysis_task(issue_analysis_agent, 
                                                                     self.code_file, 
                                                                     self.description, 
                                                                     self.line_number)
        
        create_impact_review_task = tasks.create_impact_review_task(impact_review_agent, 
                                                                    self.code_file, 
                                                                    self.description, 
                                                                    self.line_number, 
                                                                    self.project_root_dir)
        
        create_code_remediation_task = tasks.create_code_remediation_task(code_change_agent, 
                                                                          self.code_file, 
                                                                          self.description, 
                                                                          self.line_number)
        
        create_code_review_task = tasks.create_code_review_task(code_review_agent, 
                                                                self.code_file, 
                                                                self.description, 
                                                                self.line_number)
        
        create_code_rewriter_task = tasks.create_code_rewriter_task(code_rewriter_agent, 
                                                                    self.code_file)
        
        # Define your custom crew here
        crew = Crew(
            agents=[issue_analysis_agent,
                    impact_review_agent,
                    code_change_agent,
                    code_review_agent
                    ],
            tasks=[
                create_issue_analysis_task,
                create_impact_review_task,
                create_code_remediation_task,
                create_code_review_task
            ],
            verbose=True,
        )

        result = crew.kickoff()
        return result


# This is the main function that you will use to run your custom crew.
if __name__ == "__main__":
    print("## Welcome automatic test case genrator")
    print('-------------------------------')
    # file = input(
    #     dedent("""
    #   Code File Path
    # """))
    # function = input(
    #     dedent("""
    #   Function Name
    # """))
    # root_path = input(
    #     dedent("""
    #   Project Root Dirctory Path
    # """))
    file = "D:/crewAI/code-refactor/dispatch/src/dispatch/conference/models.py"
    lineNumber = "39"
    description = "jinja2.Template is called with no autoescape argument (autoescaping is disabled by default). This increases the risk of Cross-Site Scripting (XSS) attacks."
    root_path = "D:/crewAI/code-refactor/dispatch"
    trip_crew = TripCrew(code_file=file, description=description, line_number=lineNumber , project_root_dir=root_path)
    result = trip_crew.run()
    print("\n\n########################")
    print("## Here is you Trip Plan")
    print("########################\n")
    print(result)
